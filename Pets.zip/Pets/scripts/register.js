let petSalon = {

    //Address of pets
    name: "the fashion pet",
    phone: "999-999-9999",
    address: {
        country: "USA",
        city: "San Francisco",
        ZipCode: "12345",
    },
    pets:[
        //List of pets names, ages, gender, service, and breed
        {
            name: "Scooby",
            age: 80,
            gender: "male",
            service: "bath",
            breed: "dog"
        },
        {
            name: "Scrappy",
            age: 60,
            gender: "male",
            service: "shot",
            breed: "dog"
        },
        {
            name: "Tweety",
            age: 85,
            gender: "female",
            service: "shot",
            breed: "bird"
        },
        {
            name: "Sylvester",
            age: 85,
            gender: "male",
            service: "nails cut",
            breed: "cat"
        },
    
]
}
//just show the name of the pet
console.log(petSalon.pets[2].name)
//calculate the adverage age of the pets
let  totalAge = 0;
for(let i=0; i<petSalon.pets.length; i++);
{
    totalAge=totalAge+petSalon.pets[i].age;
    //totalAge+=petSalon.pets[i].age; this is another way to do it
}
let averageAge = totalAge/petSalon.pets.lenth;
console.log("the average age of the pets: "+ averageAge)
